#include <iostream>

using namespace std;

int main(){

	int v[100000], i=0, contagens=0, aux;
	cout << "Digite quantos valores quiser, -1 para parar" << endl;
	cin >> aux;
	while(aux!=-1){
		v[i] = aux;
		i++;
		cin >> aux;
	}

	cout << "Foram inseridos " << i << " números" << endl;

	int pares=0, impares=0;
	for(int j=0; j<i; j++){
		contagens++;
		if(v[j]%2==0)
			pares++;
		else
			impares++;
	}
	cout << "Existem " << pares << " números pares e " << impares << " números ímpares" << endl;

	double porc_pares = pares/double(i);
	double porc_impares = impares/double(i);
	cout << "A porcentagem de pares é " << porc_pares << " e a porcentagem de ímpares é " << porc_impares << endl;

	int zeros = 0;
	for(int j=0; j<i; j++){
		contagens++;
		if(v[j]==0)
			zeros++;
	}

	cout << zeros << " números zeros apareceram" << endl;

	int maior = -1, menor = 1000000;
	for(int j=0; j<i; j++){
		contagens+=2;
		maior = max(v[j], maior);
		menor = min(v[j], menor);
	}

	cout << "O maior número é "<< maior << " e o menor número é " << menor << endl;
	
	cout << "Houveram " << contagens << " contagens" << endl;
	
	

	return 0;
}
