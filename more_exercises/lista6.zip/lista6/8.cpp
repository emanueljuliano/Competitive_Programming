#include <iostream>

using namespace std;


int main(){
	
	cout << "Limite inferior: 3 Limite superiro: 12 Saída: 4, 6, 8, 10 Soma:28" << endl;
	return 0;
}
